import subprocess
from cleo.events.console_command_event import ConsoleCommandEvent
from cleo.events.console_events import COMMAND
from cleo.events.event_dispatcher import EventDispatcher
from poetry.console.application import Application
from poetry.plugins.application_plugin import ApplicationPlugin


class PlaywrightPostInstallUpdateHook(ApplicationPlugin):
    def activate(self, application: Application):
        print("[Poetry Plugin] Playwright hook activated (COMMAND strategy)")
        application.event_dispatcher.add_listener(COMMAND, self._on_command)

    def _run_post_install_update_hook(self):
        try:
            print("Running: playwright install --with-deps")
            subprocess.run(["playwright", "install", "--with-deps"], check=True)
        except Exception as exc:
            print(f"Error running playwright install: {exc}")

    def _on_command(self, event: ConsoleCommandEvent, event_name: str, dispatcher: EventDispatcher):
        command = event.command  # safe public access
        print(f"Command received: {command.name}")
        if command.name in ("install", "update"):
            print(f"Matched command: {command.name} — running hook")
            self._run_post_install_update_hook()
